insert into catalog(product_id, product_name, stock, unit_price) values('CATALOG-0001', 'Berlin', 100, 1500);
insert into catalog(product_id, product_name, stock, unit_price) values('CATALOG-0002', 'Tokyo', 100, 900);
insert into catalog(product_id, product_name, stock, unit_price) values('CATALOG-0003', 'Stockholm', 100, 1200);